# HPOS Compatibility Documentation

## Overview

This plugin is now fully compatible with WooCommerce's High-Performance Order Storage (HPOS), also known as Custom Order Tables (COT). The plugin automatically detects whether HPOS is enabled and uses the appropriate database tables and queries.

## What Changed

### 1. HPOS Compatibility Declaration

The plugin now declares HPOS compatibility to WooCommerce:

```php
function ce_hpriorders_declare_hpos_compatibility() {
    if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility(
            'custom_order_tables',
            CE_HPRIORDERS_PLUGIN_FILE,
            true
        );
    }
}
```

### 2. Dual Screen Support

The plugin now works with both order list screens:
- **CPT Screen**: `edit-shop_order` (traditional WordPress posts)
- **HPOS Screen**: `woocommerce_page_wc-orders` (new WooCommerce order admin)

### 3. Dual Row Class Filters

Two separate filters handle row highlighting:
- **CPT**: `post_class` filter for traditional order list
- **HPOS**: `woocommerce_order_table_row_class` filter for HPOS order list

### 4. Updated CSS Selectors

CSS now targets both order list types:
```css
/* Works with both CPT and HPOS */
.wp-list-table .order-nextday,
.wp-list-table tr.order-nextday {
    background: #fff7d6 !important;
}
```

### 5. Dual Filter Links

Two separate functions create the "Priority" filter link:
- **CPT**: `ce_hpriorders_add_priority_filter_link()` - uses `views_edit-shop_order` filter
- **HPOS**: `ce_hpriorders_add_hpos_priority_filter_link()` - uses `woocommerce_order_table_filters` filter

### 6. Dual Query Filtering

Two separate functions filter orders:
- **CPT**: `ce_hpriorders_filter_priority_orders()` - modifies WP_Query
- **HPOS**: `ce_hpriorders_filter_hpos_priority_orders()` - modifies HPOS query args

### 7. Smart Database Queries

The priority count query automatically uses the correct database tables:
- **CPT**: Queries `wp_posts` table with `post_type = 'shop_order'`
- **HPOS**: Queries `wp_wc_orders` table with `type = 'shop_order'`

## Testing HPOS Compatibility

### Enable HPOS in WooCommerce

1. Go to **WooCommerce → Settings → Advanced → Features**
2. Enable "High-performance order storage"
3. Click "Save changes"
4. WooCommerce will show a notice about migrating orders
5. Follow the migration process

### Test Checklist

- [ ] **Visual Highlighting**: Priority orders show yellow background and orange border
- [ ] **Order Tag**: Priority orders display the tag (⚡ Next-day by default)
- [ ] **Priority Filter**: "Priority" link appears in order list filters
- [ ] **Filter Count**: Count shows correct number of priority orders
- [ ] **Filter Functionality**: Clicking "Priority" shows only priority orders
- [ ] **Settings Page**: All settings save and apply correctly
- [ ] **Order Status Filter**: Orders only highlight for configured statuses
- [ ] **Shipping Method Filter**: Orders only highlight for configured methods
- [ ] **Keyword Filter**: If using keywords, they work correctly
- [ ] **Cache Clearing**: Count updates when orders are created/updated
- [ ] **Performance**: No slowdown on order list page

### Testing Both Modes

Test the plugin with:
1. **HPOS Disabled** (traditional CPT storage)
2. **HPOS Enabled** (new custom order tables)
3. **Compatibility Mode** (both enabled during migration)

All functionality should work identically in all three modes.

### Debug Mode

Enable WordPress debug mode to catch any issues:

```php
// In wp-config.php
define( 'WP_DEBUG', true );
define( 'WP_DEBUG_LOG', true );
define( 'WP_DEBUG_DISPLAY', false );
```

Check `wp-content/debug.log` for any errors or warnings.

## Technical Details

### Database Table Differences

**CPT (Traditional):**
- Orders stored in: `wp_posts`
- Order ID field: `ID`
- Order type check: `post_type = 'shop_order'`
- Status format: `post_status = 'wc-processing'`

**HPOS (New):**
- Orders stored in: `wp_wc_orders`
- Order ID field: `id`
- Order type check: `type = 'shop_order'`
- Status format: `status = 'processing'` (no `wc-` prefix)

### HPOS Detection

The plugin checks if HPOS is enabled using:

```php
function ce_hpriorders_is_hpos_enabled() {
    if ( class_exists( '\Automattic\WooCommerce\Utilities\OrderUtil' ) ) {
        return \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled();
    }
    return false;
}
```

### Backward Compatibility

The plugin maintains full backward compatibility:
- Works with WooCommerce versions without HPOS
- Gracefully handles missing HPOS classes/functions
- Falls back to CPT methods when HPOS is not available

## Performance Considerations

### Query Optimization

Both CPT and HPOS queries are optimized:
- Use indexed columns for filtering
- Leverage existing WooCommerce indexes
- Count queries cached for 5 minutes
- No impact on front-end performance

### Cache Strategy

The plugin caches priority order counts:
- Cache key includes HPOS status to prevent conflicts
- Cache cleared on order create/update/status change
- 5-minute cache lifetime balances performance and accuracy

## Support for Other Plugins

This implementation follows WooCommerce's official HPOS guidelines and should be compatible with other HPOS-compatible plugins. The plugin:

- Uses official WooCommerce APIs where available
- Declares compatibility properly
- Doesn't conflict with WooCommerce core functionality
- Follows WordPress coding standards

## Troubleshooting

### Orders Not Highlighting

1. Check if shipping methods are configured (WooCommerce → Priority Orders)
2. Verify order statuses are configured
3. Confirm orders actually use the configured shipping methods
4. Clear plugin cache by updating an order
5. Check for JavaScript console errors

### Filter Not Showing

1. Ensure at least one shipping method is configured
2. Check if there are any priority orders
3. Verify you're on the orders list page
4. Clear browser cache

### Count Incorrect

1. Clear the plugin cache by updating any order
2. Check if HPOS migration completed successfully
3. Verify shipping method IDs match your configuration
4. Enable debug mode and check for database errors

## Future Considerations

### WooCommerce 8.0+

WooCommerce 8.0 and later versions require HPOS compatibility for new installations. This plugin is ready for those requirements.

### Order Item Storage

Order items (including shipping methods) continue to use the `woocommerce_order_items` and `woocommerce_order_itemmeta` tables even with HPOS enabled. This means our shipping method queries work identically in both modes.

## Support

If you encounter any HPOS-related issues:

1. Check the troubleshooting section above
2. Enable debug mode and check logs
3. Test with only WooCommerce and this plugin active
4. Contact support with your WooCommerce version and HPOS status

## References

- [WooCommerce HPOS Documentation](https://github.com/woocommerce/woocommerce/wiki/High-Performance-Order-Storage-Upgrade-Recipe-Book)
- [WooCommerce Developer Blog: HPOS](https://developer.woocommerce.com/2022/08/03/high-performance-order-storage-backward-compatibility-tools/)
- [WordPress Coding Standards](https://developer.wordpress.org/coding-standards/wordpress-coding-standards/)

