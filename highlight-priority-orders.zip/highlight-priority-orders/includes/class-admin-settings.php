<?php
/**
 * Admin Settings Class
 *
 * Handles the admin settings page for Priority Orders.
 *
 * @package HighlightPriorityOrders
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Admin Settings Class
 */
class CE_HPriOrders_Admin_Settings {

	/**
	 * Settings page slug.
	 *
	 * @var string
	 */
	private $page_slug = 'priority-orders-settings';

	/**
	 * Constructor.
	 */
	public function __construct() {
		// Add submenu page under WooCommerce.
		add_action( 'admin_menu', array( $this, 'add_admin_menu' ), 60 );

		// Register settings.
		add_action( 'admin_init', array( $this, 'register_settings' ) );

		// Enqueue admin scripts and styles.
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_scripts' ) );
	}

	/**
	 * Add admin menu page under WooCommerce.
	 */
	public function add_admin_menu() {
		add_submenu_page(
			'woocommerce',
			__( 'Priority Orders', 'highlight-priority-orders' ),
			__( 'Priority Orders', 'highlight-priority-orders' ),
			'manage_woocommerce',
			$this->page_slug,
			array( $this, 'render_settings_page' )
		);
	}

	/**
	 * Register settings.
	 */
	public function register_settings() {
		// Register each setting.
		register_setting( 'ce_hpriorders_settings', 'ce_hpriorders_shipping_methods' );
		register_setting( 'ce_hpriorders_settings', 'ce_hpriorders_order_statuses' );
		register_setting( 'ce_hpriorders_settings', 'ce_hpriorders_tag_text' );
		register_setting( 'ce_hpriorders_settings', 'ce_hpriorders_tag_emoji' );
		register_setting( 'ce_hpriorders_settings', 'ce_hpriorders_background_color', array(
			'sanitize_callback' => 'sanitize_hex_color',
		) );
		register_setting( 'ce_hpriorders_settings', 'ce_hpriorders_border_color', array(
			'sanitize_callback' => 'sanitize_hex_color',
		) );
	}

	/**
	 * Render the settings page.
	 */
	public function render_settings_page() {
		// Check user capabilities.
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}

		// Handle form submission.
		if ( isset( $_POST['ce_hpriorders_save_settings'] ) && check_admin_referer( 'ce_hpriorders_settings_action', 'ce_hpriorders_settings_nonce' ) ) {
			$this->save_settings();
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Settings saved successfully.', 'highlight-priority-orders' ) . '</p></div>';
		}

		// Get current values.
		$shipping_methods = get_option( 'ce_hpriorders_shipping_methods', array() );
		$order_statuses   = get_option( 'ce_hpriorders_order_statuses', array( 'wc-processing' ) );
		$tag_text         = get_option( 'ce_hpriorders_tag_text', 'Next-day' );
		$tag_emoji        = get_option( 'ce_hpriorders_tag_emoji', '⚡' );
		$background_color = get_option( 'ce_hpriorders_background_color', '#fff7d6' );
		$border_color     = get_option( 'ce_hpriorders_border_color', '#f59e0b' );

		// Get options.
		$shipping_methods_options = $this->get_shipping_methods_options();
		$order_statuses_options   = $this->get_order_statuses_options();

		?>
		<div class="wrap">
			<h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
			
			<form method="post" action="">
				<?php wp_nonce_field( 'ce_hpriorders_settings_action', 'ce_hpriorders_settings_nonce' ); ?>
				
				<table class="form-table" role="presentation">
					<tbody>
						<!-- General Settings Section -->
						<tr>
							<th colspan="2">
								<h2><?php esc_html_e( 'Priority Orders Settings', 'highlight-priority-orders' ); ?></h2>
								<p class="description"><?php esc_html_e( 'Configure which orders should be highlighted in the admin orders list based on their shipping method and status.', 'highlight-priority-orders' ); ?></p>
							</th>
						</tr>

						<!-- Shipping Methods -->
						<tr>
							<th scope="row">
								<label for="ce_hpriorders_shipping_methods"><?php esc_html_e( 'Shipping Methods', 'highlight-priority-orders' ); ?></label>
							</th>
							<td>
								<select name="ce_hpriorders_shipping_methods[]" id="ce_hpriorders_shipping_methods" class="wc-enhanced-select" multiple="multiple" style="min-width: 500px;" data-placeholder="<?php esc_attr_e( 'Select shipping methods...', 'highlight-priority-orders' ); ?>">
									<?php foreach ( $shipping_methods_options as $value => $label ) : ?>
										<option value="<?php echo esc_attr( $value ); ?>" <?php selected( in_array( $value, (array) $shipping_methods, true ) ); ?>>
											<?php echo esc_html( $label ); ?>
										</option>
									<?php endforeach; ?>
								</select>
								<p class="description"><?php esc_html_e( 'Select which shipping methods should be considered as priority/next-day delivery.', 'highlight-priority-orders' ); ?></p>
							</td>
						</tr>

						<!-- Order Statuses -->
						<tr>
							<th scope="row">
								<label for="ce_hpriorders_order_statuses"><?php esc_html_e( 'Order Statuses', 'highlight-priority-orders' ); ?></label>
							</th>
							<td>
								<select name="ce_hpriorders_order_statuses[]" id="ce_hpriorders_order_statuses" class="wc-enhanced-select" multiple="multiple" style="min-width: 500px;" data-placeholder="<?php esc_attr_e( 'Select order statuses...', 'highlight-priority-orders' ); ?>">
									<?php foreach ( $order_statuses_options as $value => $label ) : ?>
										<option value="<?php echo esc_attr( $value ); ?>" <?php selected( in_array( $value, (array) $order_statuses, true ) ); ?>>
											<?php echo esc_html( $label ); ?>
										</option>
									<?php endforeach; ?>
								</select>
								<p class="description"><?php esc_html_e( 'Select which order statuses should be highlighted when they use priority shipping.', 'highlight-priority-orders' ); ?></p>
							</td>
						</tr>

						<!-- Appearance Section -->
						<tr>
							<th colspan="2">
								<h2><?php esc_html_e( 'Appearance', 'highlight-priority-orders' ); ?></h2>
								<p class="description"><?php esc_html_e( 'Customize the visual appearance of highlighted orders. All appearance settings are optional.', 'highlight-priority-orders' ); ?></p>
							</th>
						</tr>

						<!-- Tag Text -->
						<tr>
							<th scope="row">
								<label for="ce_hpriorders_tag_text"><?php esc_html_e( 'Tag Text', 'highlight-priority-orders' ); ?></label>
							</th>
							<td>
								<input type="text" name="ce_hpriorders_tag_text" id="ce_hpriorders_tag_text" value="<?php echo esc_attr( $tag_text ); ?>" class="regular-text">
								<p class="description"><?php esc_html_e( 'The text displayed in the order tag (without emoji).', 'highlight-priority-orders' ); ?></p>
							</td>
						</tr>

						<!-- Tag Icon -->
						<tr>
							<th scope="row">
								<label for="ce_hpriorders_tag_emoji"><?php esc_html_e( 'Tag Icon', 'highlight-priority-orders' ); ?></label>
							</th>
							<td>
								<input type="text" name="ce_hpriorders_tag_emoji" id="ce_hpriorders_tag_emoji" value="<?php echo esc_attr( $tag_emoji ); ?>" style="max-width: 100px;">
								<p class="description"><?php esc_html_e( 'The icon displayed before the tag text. Leave empty for no icon.', 'highlight-priority-orders' ); ?></p>
							</td>
						</tr>

						<!-- Background Color -->
						<tr>
							<th scope="row">
								<label for="ce_hpriorders_background_color"><?php esc_html_e( 'Background Color', 'highlight-priority-orders' ); ?></label>
							</th>
							<td>
								<input type="text" name="ce_hpriorders_background_color" id="ce_hpriorders_background_color" value="<?php echo esc_attr( $background_color ); ?>" class="color-picker" data-default-color="#fff7d6">
								<button type="button" class="button button-secondary color-reset-button" data-target="ce_hpriorders_background_color" data-default="#fff7d6" style="margin-left: 10px;"><?php esc_html_e( 'Reset to Default', 'highlight-priority-orders' ); ?></button>
								<p class="description"><?php esc_html_e( 'The background color for highlighted order rows. Default is a soft yellow (#fff7d6).', 'highlight-priority-orders' ); ?></p>
							</td>
						</tr>

						<!-- Border Color -->
						<tr>
							<th scope="row">
								<label for="ce_hpriorders_border_color"><?php esc_html_e( 'Border Color', 'highlight-priority-orders' ); ?></label>
							</th>
							<td>
								<input type="text" name="ce_hpriorders_border_color" id="ce_hpriorders_border_color" value="<?php echo esc_attr( $border_color ); ?>" class="color-picker" data-default-color="#f59e0b">
								<button type="button" class="button button-secondary color-reset-button" data-target="ce_hpriorders_border_color" data-default="#f59e0b" style="margin-left: 10px;"><?php esc_html_e( 'Reset to Default', 'highlight-priority-orders' ); ?></button>
								<p class="description"><?php esc_html_e( 'The color of the left border and tag text on highlighted order rows. Default is orange (#f59e0b).', 'highlight-priority-orders' ); ?></p>
							</td>
						</tr>
					</tbody>
				</table>

				<?php submit_button( __( 'Save Settings', 'highlight-priority-orders' ), 'primary', 'ce_hpriorders_save_settings' ); ?>
			</form>
		</div>
		<?php
	}

	/**
	 * Save settings.
	 */
	private function save_settings() {
		// Verify nonce is already checked in render_settings_page().
		
		// Save shipping methods.
		$shipping_methods = isset( $_POST['ce_hpriorders_shipping_methods'] ) ? array_map( 'sanitize_text_field', wp_unslash( $_POST['ce_hpriorders_shipping_methods'] ) ) : array();
		update_option( 'ce_hpriorders_shipping_methods', $shipping_methods );

		// Save order statuses.
		$order_statuses = isset( $_POST['ce_hpriorders_order_statuses'] ) ? array_map( 'sanitize_text_field', wp_unslash( $_POST['ce_hpriorders_order_statuses'] ) ) : array();
		update_option( 'ce_hpriorders_order_statuses', $order_statuses );

		// Save tag text.
		$tag_text = isset( $_POST['ce_hpriorders_tag_text'] ) ? sanitize_text_field( wp_unslash( $_POST['ce_hpriorders_tag_text'] ) ) : 'Next-day';
		update_option( 'ce_hpriorders_tag_text', $tag_text );

		// Save tag emoji.
		$tag_emoji = isset( $_POST['ce_hpriorders_tag_emoji'] ) ? sanitize_text_field( wp_unslash( $_POST['ce_hpriorders_tag_emoji'] ) ) : '⚡';
		update_option( 'ce_hpriorders_tag_emoji', $tag_emoji );

		// Save background color.
		$background_color = isset( $_POST['ce_hpriorders_background_color'] ) ? sanitize_hex_color( wp_unslash( $_POST['ce_hpriorders_background_color'] ) ) : '#fff7d6';
		update_option( 'ce_hpriorders_background_color', $background_color );

		// Save border color.
		$border_color = isset( $_POST['ce_hpriorders_border_color'] ) ? sanitize_hex_color( wp_unslash( $_POST['ce_hpriorders_border_color'] ) ) : '#f59e0b';
		update_option( 'ce_hpriorders_border_color', $border_color );

		// Clear cache.
		ce_hpriorders_clear_count_cache();
	}


	/**
	 * Get shipping methods options for multiselect.
	 *
	 * @return array
	 */
	private function get_shipping_methods_options() {
		$options = array();

		// Get all shipping zones.
		$zones = WC_Shipping_Zones::get_zones();

		foreach ( $zones as $zone ) {
			$zone_name = $zone['zone_name'];

			foreach ( $zone['shipping_methods'] as $method ) {
				if ( 'yes' !== $method->enabled ) {
					continue;
				}

				$method_id   = $method->id;
				$instance_id = $method->instance_id;
				$full_id     = "{$method_id}:{$instance_id}";
				$title       = $method->get_title();

				// Format: "Zone Name - Method Title (method_id:instance_id)".
				$label = sprintf(
					'%s - %s (%s)',
					$zone_name,
					$title,
					$full_id
				);

				$options[ $full_id ] = $label;
			}
		}

		// Get methods from the "Rest of the World" zone (zone ID 0).
		$zone_0 = new WC_Shipping_Zone( 0 );
		$methods = $zone_0->get_shipping_methods();

		foreach ( $methods as $method ) {
			if ( 'yes' !== $method->enabled ) {
				continue;
			}

			$method_id   = $method->id;
			$instance_id = $method->instance_id;
			$full_id     = "{$method_id}:{$instance_id}";
			$title       = $method->get_title();

			$label = sprintf(
				'%s - %s (%s)',
				__( 'Rest of the World', 'highlight-priority-orders' ),
				$title,
				$full_id
			);

			$options[ $full_id ] = $label;
		}

		return $options;
	}

	/**
	 * Get order statuses options for multiselect.
	 *
	 * @return array
	 */
	private function get_order_statuses_options() {
		$statuses = wc_get_order_statuses();
		return $statuses;
	}

	/**
	 * Enqueue admin scripts and styles.
	 *
	 * @param string $hook The current admin page hook.
	 */
	public function enqueue_admin_scripts( $hook ) {
		// Only load on our settings page.
		// Check for both possible hook formats.
		$expected_hooks = array(
			'woocommerce_page_' . $this->page_slug,
			'toplevel_page_' . $this->page_slug,
		);
		
		if ( ! in_array( $hook, $expected_hooks, true ) ) {
			return;
		}

		// Enqueue WordPress color picker with all dependencies.
		wp_enqueue_style( 'wp-color-picker' );
		wp_enqueue_script( 'iris' );
		wp_enqueue_script( 'wp-color-picker' );
		
		// Enqueue select2 CSS - this is critical!
		wp_enqueue_style( 'select2' );
		
		// Enqueue WooCommerce admin scripts and styles.
		wp_enqueue_style( 'woocommerce_admin_styles' );
		wp_enqueue_script( 'wc-enhanced-select' );
		
		// Enqueue our custom script with proper dependencies.
		wp_register_script(
			'ce-hpriorders-admin',
			false,
			array( 'jquery', 'iris', 'wp-color-picker', 'wc-enhanced-select' ),
			CE_HPRIORDERS_VERSION,
			true
		);
		wp_enqueue_script( 'ce-hpriorders-admin' );

		// Add custom styles for better UX.
		wp_add_inline_style(
			'woocommerce_admin_styles',
			'
			/* Enhanced select2 styling for better UX */
			.select2-container {
				min-width: 400px !important;
			}
			
			.select2-container--default .select2-selection--multiple {
				min-height: 150px;
				min-width: 400px;
				padding: 8px;
				border: 1px solid #8c8f94;
				border-radius: 4px;
				box-sizing: border-box;
			}
			
			.select2-container--default.select2-container--focus .select2-selection--multiple {
				border-color: #2271b1;
				box-shadow: 0 0 0 1px #2271b1;
			}
			
			.select2-container--default .select2-selection--multiple .select2-selection__choice {
				background-color: #2271b1;
				border: 1px solid #2271b1;
				border-radius: 3px;
				padding: 6px 10px;
				margin: 4px 6px 4px 0;
				color: #fff;
				font-size: 13px;
				line-height: 1.4;
			}
			
			.select2-container--default .select2-selection--multiple .select2-selection__choice__remove {
				color: #fff;
				margin-right: 8px;
				font-weight: bold;
				font-size: 16px;
				opacity: 0.8;
				transition: opacity 0.2s ease;
			}
			
			.select2-container--default .select2-selection--multiple .select2-selection__choice__remove:hover {
				opacity: 1;
				color: #fff;
			}
			
			.select2-container--default .select2-search--inline .select2-search__field {
				margin-top: 4px;
				margin-left: 4px;
				padding: 6px;
				font-size: 13px;
				min-width: 150px;
			}
			
			.select2-container--default .select2-search--inline .select2-search__field::placeholder {
				color: #757575;
				opacity: 0.7;
			}
			
			.select2-container--default .select2-results__option--highlighted[aria-selected] {
				background-color: #2271b1;
			}
			
			.select2-results__option {
				padding: 10px 14px;
			}
			
			.select2-container .select2-selection--multiple {
				max-height: 300px;
				overflow-y: auto;
			}
			
			.select2-dropdown {
				border: 1px solid #8c8f94;
				border-radius: 4px;
				min-width: 400px;
			}
			
			.select2-search--dropdown .select2-search__field {
				padding: 8px;
				border: 1px solid #8c8f94;
				border-radius: 3px;
			}
			
			/* Ensure the wrapper also respects min-width */
			#ce_hpriorders_shipping_methods + .select2-container,
			#ce_hpriorders_order_statuses + .select2-container {
				min-width: 500px !important;
			}
			
			/* Better empty state */
			.select2-container--default .select2-selection--multiple .select2-selection__rendered {
				display: block;
				padding-bottom: 6px;
			}
			'
		);

		// Add inline script for initialization.
		$init_script = "
		(function($) {
			'use strict';
			
			var debugMode = " . ( defined( 'WP_DEBUG' ) && WP_DEBUG ? 'true' : 'false' ) . ";
			
			function initPriorityOrdersSettings() {
				// Initialize color pickers - ensure iris is loaded
				if ($.fn.wpColorPicker && $.fn.iris) {
					try {
						$('.color-picker').wpColorPicker({
							change: function(event, ui) {
								// Trigger change event for any listeners
								$(this).val(ui.color.toString()).trigger('change');
							}
						});
					} catch(e) {
						if (debugMode && window.console) {
							console.error('Priority Orders: Error initializing color picker:', e);
						}
					}
				} else {
					// Retry after a delay in case scripts are loading slowly
					setTimeout(function() {
						if ($.fn.wpColorPicker && $.fn.iris) {
							$('.color-picker').wpColorPicker({
								change: function(event, ui) {
									$(this).val(ui.color.toString()).trigger('change');
								}
							});
						} else if (debugMode && window.console) {
							console.error('Priority Orders: Color picker dependencies not loaded');
						}
					}, 500);
				}

				// Initialize enhanced select with better UX configuration
				var selectConfig = {
					width: 'resolve',
					placeholder: function() {
						return $(this).data('placeholder');
					},
					allowClear: false,
					closeOnSelect: false,
					minimumResultsForSearch: 5,
					dropdownAutoWidth: true,
					templateResult: function(data) {
						if (!data.id) {
							return data.text;
						}
						return $('<span style=\"display: block; padding: 2px 0;\">' + data.text + '</span>');
					},
					templateSelection: function(data) {
						return data.text;
					},
					language: {
						noResults: function() {
							return '" . esc_js( __( 'No matches found', 'highlight-priority-orders' ) ) . "';
						},
						searching: function() {
							return '" . esc_js( __( 'Searching...', 'highlight-priority-orders' ) ) . "';
						},
						inputTooShort: function() {
							return '" . esc_js( __( 'Start typing to search...', 'highlight-priority-orders' ) ) . "';
						}
					}
				};
				
				if ($.fn.selectWoo) {
					$('.wc-enhanced-select').selectWoo(selectConfig);
				} else if ($.fn.select2) {
					$('.wc-enhanced-select').select2(selectConfig);
				} else if (debugMode && window.console) {
					console.error('Priority Orders: Neither selectWoo nor select2 available');
				}

				// Handle reset button clicks
				$('.color-reset-button').on('click', function(e) {
					e.preventDefault();
					var targetId = $(this).data('target');
					var defaultColor = $(this).data('default');
					var \$input = $('#' + targetId);
					
					\$input.val(defaultColor);
					
					if ($.fn.wpColorPicker) {
						\$input.wpColorPicker('color', defaultColor);
					}
				});
			}
			
			// Try initialization on document ready and window load
			$(document).ready(initPriorityOrdersSettings);
			$(window).on('load', function() {
				// Re-init if select2 wasn't available on first try
				if ($('.wc-enhanced-select').length && !$('.wc-enhanced-select').hasClass('select2-hidden-accessible')) {
					setTimeout(initPriorityOrdersSettings, 100);
				}
			});
			
		})(jQuery);
		";
		
		wp_add_inline_script( 'ce-hpriorders-admin', $init_script );
	}
}

