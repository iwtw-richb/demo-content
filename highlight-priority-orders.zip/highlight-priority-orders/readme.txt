=== Highlight Priority Orders for WooCommerce ===
Contributors: coreessentials
Tags: woocommerce, orders, nextday, delivery, hpos
Requires at least: 5.8
Tested up to: 6.9
Requires PHP: 7.4
Stable tag: 1.0.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Highlight WooCommerce orders with high priority based on shipping type and order status for easy visibility.

## Description

Helps you and your staff quickly identify orders that require priority handling by:

- **Visual highlighting** in the WooCommerce orders list for next-day/express orders or whichever shipping methodsyou select
- Adding a distinctive **⚡ Next-day** customisable tag to order items (customisable)
- Making priority orders stand out with a yellow background and orange left border, you can customise the colours.

## Features

- **Customisable Visual Order Indicators**: Soft yellow highlight with an orange left border on priority orders
- **Customisable Order Tags**: Defaults to lightning bolt logo and "Next-day" label on qualifying orders
- **Add Keyword Matching**: Keyword Matching (Advanced: e.g 'Next Day' or  'Express')
- **Priority Orders Filter**: Dedicated filter in the orders list to view only priority orders
- **Flexible Matching**: Match by specific shipping methods and order status
- **Highly Customizable**: Admin settings page with color pickers and customisable options
- **Order Status Specific**: Only highlights orders with specific statuses (default: "processing")

## Requirements

- WordPress 5.8 or higher
- PHP 7.4 or higher
- WooCommerce 5.0 or higher
- Compatible with WooCommerce High-Performance Order Storage (HPOS)

## Installation

1. Upload the `highlight-priority-orders` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to **WooCommerce → Settings → Priority Orders** to configure the plugin
4. Select your priority shipping methods and customize the settings

## Using the Priority Filter

Once you've configured your shipping methods, you'll see a new **"Priority"** filter in the top menu of your orders list:
```
All (957) | Pending payment (1) | Processing (10) | Priority (5) | ...
```

Click on **Priority** to view only orders with priority shipping methods. The filter uses efficient database queries and works seamlessly with WooCommerce's pagination!

## Configuration

### Admin Settings (Recommended)

Navigate to **WooCommerce → Priority Orders** to configure the plugin using the user-friendly admin interface:

**General Settings:**
- **Shipping Methods**: Select which shipping methods should be considered as priority (e.g 'next-day delivery')
- **Order Statuses**: Choose which order statuses should be highlighted (e.g. Processing, On-hold, Pending)

**Appearance (All Optional):**
- **Tag Text**: Customize the text shown in the order tag (default: "Next-day")
- **Tag Icon**: Customize or remove the emoji (default: ⚡)
- **Background Color**: Set the background color for priority rows
- **Border Color**: Set the left border and tag text color for priority rows

### Advanced Configuration (Filters)

Developers can still use WordPress filters to override settings programmatically:

**Override Shipping Method IDs:**
```php
add_filter( 'ce_nextday_method_ids', function( $method_ids ) {
    return array(
        'flat_rate:7',
        'royal_mail_special_delivery',
        'dhl_express',
    );
});
```

**Add Keyword Matching (Advanced):**
```php
// Match orders by keywords in shipping method names (if needed)
add_filter( 'ce_nextday_keywords', function( $keywords ) {
    return array(
        'next day',
        'next-day',
        'express',
        'special delivery',
        'priority',
    );
});
```

**Override Order Statuses:**
```php
add_filter( 'ce_nextday_include_statuses', function( $statuses ) {
    return array(
        'processing',
        'on-hold',
        'pending',
    );
});
```
## Frequently Asked Questions

### Do I need to configure both shipping methods and order statuses?

**Order statuses are required.** The plugin needs to know which order statuses to check (default is "Processing") This allows great visibility for staff as when an order is marked as completed it is no longer highlighted.

**At least one is required:**
- Shipping methods (selected in settings), OR
- Keywords (added via filter code)

Without at least one way to identify priority orders, nothing will be highlighted.

### Why aren't my orders being highlighted?

Check these common issues:

1. **No shipping methods selected** - Go to WooCommerce → Priority Orders and select at least one shipping method
2. **Wrong order status** - Make sure your orders have a status you've selected in the settings

### Can I customize the colors and text?

Yes! Go to **WooCommerce → Priority Orders** and customize:

- Tag text (e.g., "Express", "Urgent", "Priority")
- Tag icon/emoji (or leave blank)
- Background color
- Border color

All appearance settings are optional.

### What are keywords and how do they work?

Keywords are an advanced feature that lets you highlight orders based on text in the shipping method name. Instead of selecting specific shipping method IDs, keywords automatically catch any shipping method containing those words.

**Example:** A keyword "Express" would match "DHL Express", "FedEx Express", and "Royal Mail Express 24".

Keywords are case-insensitive and support partial matches. They only search the shipping method name (what customers see at checkout), not order notes, product names, or other fields.

### How do I use keyword matching?

Keywords require adding code to your theme's `functions.php` or a custom plugin:

```php
add_filter( 'ce_nextday_keywords', 'my_priority_keywords' );
function my_priority_keywords( $keywords ) {
    return array( 'Next Day', 'Express', 'Priority' );
}
```

See the **Advanced Configuration** section above for the code example.

### What's the difference between keywords and shipping methods?

- **Shipping Methods** (UI setting): Select specific method IDs like `flat_rate:5` - precise but requires manual selection
- **Keywords** (code filter): Match any shipping method name containing your keywords, great if you have lots of similarly named shipping methods - flexible but requires code

You can use both together! Orders will be highlighted if they match EITHER a keyword OR a selected shipping method (plus they must match an order status).

### Where do keywords search?

Keywords **ONLY** search the shipping method name (what customers see at checkout), such as:
- "Royal Mail Next Day Delivery"
- "DHL Express 24 Hour"
- "FedEx Priority Overnight"

Keywords do **NOT** search:
- Product names or SKUs
- Order notes (customer or admin)
- Shipping addresses
- Custom order fields
- Order metadata

### Can I use keywords without writing code?

Currently, keywords require adding a filter via code. However, you can use the **Shipping Methods** setting in the admin panel to select specific shipping methods without any coding.

A future version may add keyword configuration to the admin UI if enough people find it useful.

### How does the Priority filter work?

Once configured, you'll see a "Priority" link in the orders list (next to "All", "Processing", etc.) showing the count of priority orders. Clicking it filters the list to show only orders matching your shipping methods/keywords AND order statuses, great if you need to just ship priority orders quickly.

### Are there any performance concerns?

No! The plugin:
- Uses efficient database queries with proper indexing
- Caches the priority order count for 5 minutes
- Only runs highlighting on the orders list page
- Has minimal impact on site performance

### Can I highlight orders based on other criteria?

The plugin is designed specifically for shipping-based priority orders. If you need to highlight orders based on other criteria (products, customer types, custom fields), please contact us if you require custom development.

### Is this plugin compatible with HPOS (High-Performance Order Storage)?

Yes! This plugin is fully compatible with WooCommerce's High-Performance Order Storage (HPOS). It automatically detects whether HPOS is enabled and uses the appropriate database tables and queries. The plugin works seamlessly with both:

- Traditional WooCommerce order storage (CPT - Custom Post Types)
- New HPOS storage (custom order tables)

You don't need to do anything special - the plugin handles everything automatically!

### What happens if I use both keywords and shipping methods?

They work together with **OR** logic:

Orders are highlighted if they have:
- (Keyword match **OR** Shipping method ID match) **AND** (Order status match)

**Example:**
- Keywords: `['Express']`
- Shipping Methods: `flat_rate:5`
- Order Statuses: `Processing`

**Result:** Orders with "Express" in shipping name OR `flat_rate:5` method AND Processing status will be highlighted.

### Can I highlight orders regardless of shipping method?

Not currently. The plugin requires either:
- At least one shipping method selected, OR
- Keywords configured via filter

This is by design - the plugin is meant for shipping-based priority highlighting.

## Changelog

### 1.0.1
- Added full HPOS (High-Performance Order Storage) compatibility
- Plugin now works seamlessly with both CPT and HPOS order storage
- Automatic detection and switching between storage methods
- Enhanced performance with HPOS-optimized queries

### 1.0.0
- Initial release
- Admin order list highlighting
- Checkout shipping notice
- Multiple customization filters