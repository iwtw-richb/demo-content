# Keyword Matching FAQ

## 📚 Table of Contents
- [What Are Keywords?](#what-are-keywords)
- [How Do I Use Keywords?](#how-do-i-use-keywords)
- [Where Do Keywords Search?](#where-do-keywords-search)
- [Common Scenarios](#common-scenarios)
- [Examples](#examples)
- [Troubleshooting](#troubleshooting)

---

## What Are Keywords?

Keywords are text phrases that the plugin searches for in your shipping method names to automatically identify priority orders. Instead of manually selecting every shipping method ID in the settings, you can use keywords to catch multiple shipping methods at once.

**Think of it like this:**
- **Shipping Method IDs** = Specific addresses (e.g., "123 Main Street")
- **Keywords** = Neighborhood names (e.g., "Downtown" catches all Downtown addresses)

---

## How Do I Use Keywords?

Keywords are **developer-only** and require adding code to your site. There's no UI setting for them (yet).

### Step 1: Add the Code

Add this to your theme's `functions.php` file or a custom plugin:

```php
add_filter( 'ce_nextday_keywords', 'my_priority_keywords' );
function my_priority_keywords( $keywords ) {
    return array(
        'Next Day',
        'Express',
        'Priority',
        'Urgent',
        '24 Hour'
    );
}
```

### Step 2: Save and Test

That's it! Orders with shipping methods containing these words will now be considered priority orders (if they also match your configured order statuses).

---

## Where Do Keywords Search?

### ✅ Keywords Search:
- **Shipping method name/label** (what customers see at checkout)
  - Example: "Royal Mail Next Day Delivery"
  - Example: "DHL Express 24 Hour Service"
  - Example: "FedEx Priority Overnight"

### ❌ Keywords DO NOT Search:
- Product names or SKUs
- Order notes (customer or admin)
- Shipping addresses
- Custom order fields
- Order metadata
- Customer names or emails
- Anything except the shipping method name

---

## Common Scenarios

### Scenario 1: Keywords + Shipping Methods + Order Statuses (Recommended)

**Configuration:**
- Keywords: `['Next Day', 'Express']`
- Shipping Methods: `flat_rate:5` (selected in settings)
- Order Statuses: `Processing` (selected in settings)

**Result:** Orders highlighted if they have:
- Shipping method name containing "Next Day" **OR** "Express" **OR** `flat_rate:5`
- **AND** Order status is "Processing"

**Why use this?** Best of both worlds - catch keyword matches AND specific method IDs you select.

---

### Scenario 2: Keywords Only (No Shipping Methods Selected)

**Configuration:**
- Keywords: `['Next Day', 'Express']`
- Shipping Methods: *(none selected)*
- Order Statuses: `Processing` (selected in settings)

**Result:** Orders highlighted if they have:
- Shipping method name containing "Next Day" **OR** "Express"
- **AND** Order status is "Processing"

**Why use this?** Great if your shipping method names are consistent and descriptive.

---

### Scenario 3: Shipping Methods Only (No Keywords)

**Configuration:**
- Keywords: *(no filter added)*
- Shipping Methods: `flat_rate:5, flat_rate:7` (selected in settings)
- Order Statuses: `Processing` (selected in settings)

**Result:** Orders highlighted if they have:
- Shipping method ID of `flat_rate:5` **OR** `flat_rate:7`
- **AND** Order status is "Processing"

**Why use this?** Most precise - only specific shipping methods you select.

---

### ⚠️ Scenario 4: No Keywords + No Shipping Methods

**Configuration:**
- Keywords: *(no filter added)*
- Shipping Methods: *(none selected)*
- Order Statuses: `Processing` (selected in settings)

**Result:** ❌ **NOTHING IS HIGHLIGHTED**

**Why?** The plugin needs at least one way to identify priority orders (keywords OR shipping methods).

---

## Examples

### Example 1: Multi-Carrier Setup

You use multiple shipping carriers, all with "Express" in the name:

```php
add_filter( 'ce_nextday_keywords', 'my_priority_keywords' );
function my_priority_keywords( $keywords ) {
    return array( 'Express' );
}
```

**Catches:**
- ✅ "DHL Express Worldwide"
- ✅ "FedEx International Express"
- ✅ "Royal Mail Express 24"
- ✅ "UPS Express Saver"

**Misses:**
- ❌ "Standard Delivery"
- ❌ "Economy Shipping"

---

### Example 2: Multiple Keywords for Variations

Your shipping methods use different wording:

```php
add_filter( 'ce_nextday_keywords', 'my_priority_keywords' );
function my_priority_keywords( $keywords ) {
    return array(
        'Next Day',
        'Next-Day',
        'Nextday',
        '24 Hour',
        '24hr'
    );
}
```

**Catches:**
- ✅ "Next Day Delivery"
- ✅ "Next-Day Service"
- ✅ "Nextday Express"
- ✅ "24 Hour Delivery"
- ✅ "Express 24hr"

---

### Example 3: Time-Specific Services

You want to catch all timed deliveries:

```php
add_filter( 'ce_nextday_keywords', 'my_priority_keywords' );
function my_priority_keywords( $keywords ) {
    return array(
        'Next Day',
        'Same Day',
        '1pm',
        '9am',
        'Before 10',
        'Before 12'
    );
}
```

**Catches:**
- ✅ "Next Day Delivery (Order by 1pm)"
- ✅ "Same Day Delivery"
- ✅ "Before 12 Delivery Service"
- ✅ "Guaranteed Before 10"

---

### Example 4: Priority Levels

You have priority tiers:

```php
add_filter( 'ce_nextday_keywords', 'my_priority_keywords' );
function my_priority_keywords( $keywords ) {
    return array(
        'Priority',
        'Urgent',
        'Rush',
        'Emergency'
    );
}
```

**Catches:**
- ✅ "Priority Mail"
- ✅ "Urgent Delivery Service"
- ✅ "Rush Order Shipping"
- ✅ "Emergency 2-Hour Delivery"

---

## Troubleshooting

### ❓ My keywords aren't working

**Check:**
1. Did you add the filter code to `functions.php` or a custom plugin?
2. Is the code syntax correct? (missing quotes, commas, parentheses?)
3. Did you select **Order Statuses** in the plugin settings?
4. Are the orders actually using a shipping method with that keyword in the name?

**Debug:**
Add this temporarily to see what shipping method names look like:
```php
add_action( 'woocommerce_checkout_order_processed', function( $order_id ) {
    $order = wc_get_order( $order_id );
    foreach ( $order->get_shipping_methods() as $item ) {
        error_log( 'Shipping method name: ' . $item->get_name() );
    }
});
```

Check your WordPress debug log to see the exact shipping method names.

---

### ❓ Too many orders are being highlighted

**Possible causes:**
1. Your keyword is too generic (e.g., "Day" catches "Same Day", "Next Day", "2-3 Day")
2. Your keyword appears in non-priority shipping methods

**Solutions:**
- Be more specific with keywords (e.g., "Next Day" instead of "Day")
- Use exact shipping method IDs in settings instead of keywords
- Refine your keywords to be more precise

---

### ❓ Some priority orders aren't being highlighted

**Possible causes:**
1. Shipping method name doesn't contain your keywords
2. Order status doesn't match your configured statuses
3. Keyword spelling doesn't match exactly (e.g., "Nextday" vs "Next Day")

**Solutions:**
- Add more keyword variations to catch different spellings
- Check what the actual shipping method names are (use debug code above)
- Make sure your Order Statuses setting includes all relevant statuses

---

### ❓ Can I search order notes or product names?

**Not currently.** Keywords only search shipping method names. If you need to search other fields, that would require custom development or a plugin modification.

---

### ❓ Are keywords case-sensitive?

**No!** The search is case-insensitive:
- Keyword: `"express"` matches "Express", "EXPRESS", "Express"
- Keyword: `"Next Day"` matches "next day", "NEXT DAY", "Next day"

---

### ❓ Do I need to use keywords AND shipping methods?

**No!** You can use:
- **Keywords only** (developer filter)
- **Shipping methods only** (UI settings)
- **Both together** (recommended for flexibility)

Using both gives you the best of both worlds:
- Keywords catch general patterns
- Shipping method IDs catch specific methods that don't fit the pattern

---

### ❓ Can I use wildcards or regex?

**Not currently.** Keywords use simple text matching (partial, case-insensitive). If you need advanced pattern matching, that would require custom development.

---

### ❓ Where do I add the keyword filter code?

**Best practices:**

1. **Child Theme's functions.php** (Recommended)
   - Location: `wp-content/themes/your-child-theme/functions.php`
   - Survives theme updates

2. **Code Snippets Plugin** (Also good)
   - Install "Code Snippets" plugin
   - Add as a new snippet
   - Easy to manage, no file editing

3. **Custom Plugin** (Advanced)
   - Create your own small plugin
   - Most professional approach
   - Survives all theme changes

**Don't use:**
- ❌ Parent theme's functions.php (lost on theme updates)
- ❌ Random plugin files (hard to maintain)

---

## Quick Reference

### Filter Hook
```php
add_filter( 'ce_nextday_keywords', 'your_function_name' );
```

### Basic Example
```php
function your_function_name( $keywords ) {
    return array( 'Next Day', 'Express', 'Priority' );
}
```

### How Highlighting Works
```
Order is highlighted IF:
  (Keyword matches OR Shipping method ID matches)
  AND
  (Order status matches)
```

### Search Behavior
- ✅ Case-insensitive
- ✅ Partial matches
- ✅ Searches shipping method name only
- ❌ No wildcards/regex
- ❌ Doesn't search other order fields

---

## Need More Help?

Check the plugin's main documentation or visit the support forum for assistance.

