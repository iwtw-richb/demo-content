<?php
/**
 * Plugin Name: Highlight Priority Orders for WooCommerce
 * Description: Highlight WooCommerce orders with high priority based on shipping type and order status for easy visibility.
 * Version: 1.0.1
 * Plugin URI:      https://coreessentials.online/plugins-for-wordpress/coreessentials-email-gated-downloads/
 * Author:          Core Essentials
 * Author URI:      https://coreessentials.online/
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * Text Domain: highlight-priority-orders
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 *
 * @package HighlightPriorityOrders
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Cleanup function for uninstall.
 * Called by Freemius after uninstall event is tracked.
 */
function hpofw_fs_uninstall_cleanup() {
	// Remove plugin options.
	delete_option( 'ce_hpriorders_shipping_methods' );
	delete_option( 'ce_hpriorders_order_statuses' );
	delete_option( 'ce_hpriorders_tag_text' );
	delete_option( 'ce_hpriorders_tag_emoji' );
	delete_option( 'ce_hpriorders_background_color' );
	delete_option( 'ce_hpriorders_border_color' );
}

// Define plugin constants.
define( 'CE_HPRIORDERS_VERSION', '1.0.1' );
define( 'CE_HPRIORDERS_PLUGIN_FILE', __FILE__ );
define( 'CE_HPRIORDERS_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'CE_HPRIORDERS_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'CE_HPRIORDERS_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );

/**
 * Check if WooCommerce is active.
 *
 * @return bool
 */
function ce_hpriorders_is_woocommerce_active() {
	return class_exists( 'WooCommerce' );
}

/**
 * Display admin notice if WooCommerce is not active.
 */
function ce_hpriorders_woocommerce_missing_notice() {
	?>
	<div class="notice notice-error">
		<p>
			<?php
			printf(
				/* translators: %s: Plugin name */
				esc_html__( '%s requires WooCommerce to be installed and active.', 'highlight-priority-orders' ),
				'<strong>CE – Highlight Next-Day Orders</strong>'
			);
			?>
		</p>
	</div>
	<?php
}

/**
 * Initialize the plugin.
 */
function ce_hpriorders_init() {
	// Check if WooCommerce is active.
	if ( ! ce_hpriorders_is_woocommerce_active() ) {
		add_action( 'admin_notices', 'ce_hpriorders_woocommerce_missing_notice' );
		return;
	}

	// Declare HPOS compatibility.
	add_action( 'before_woocommerce_init', 'ce_hpriorders_declare_hpos_compatibility' );

	// Load plugin functionality.
	ce_hpriorders_load_features();
}
add_action( 'plugins_loaded', 'ce_hpriorders_init' );

/**
 * Declare HPOS (High-Performance Order Storage) compatibility.
 */
function ce_hpriorders_declare_hpos_compatibility() {
	if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility(
			'custom_order_tables',
			CE_HPRIORDERS_PLUGIN_FILE,
			true
		);
	}
}

/**
 * Load plugin features.
 */
function ce_hpriorders_load_features() {
	// Load admin settings.
	if ( is_admin() ) {
		ce_hpriorders_load_admin_settings();
		add_filter( 'plugin_action_links_' . CE_HPRIORDERS_PLUGIN_BASENAME, 'ce_hpriorders_add_settings_link' );
	}

	// Admin order list highlighting - works with both CPT and HPOS.
	add_filter( 'post_class', 'ce_hpriorders_add_order_class', 10, 3 );
	add_action( 'admin_head-edit.php', 'ce_hpriorders_admin_order_list_styles' );
	add_action( 'admin_head-woocommerce_page_wc-orders', 'ce_hpriorders_admin_order_list_styles' );
	add_filter( 'woocommerce_order_table_row_class', 'ce_hpriorders_add_hpos_order_class', 10, 2 );

	// Add priority orders filter to orders list - works with both CPT and HPOS.
	add_filter( 'views_edit-shop_order', 'ce_hpriorders_add_priority_filter_link' );
	add_filter( 'woocommerce_order_table_filters', 'ce_hpriorders_add_hpos_priority_filter_link' );
	add_action( 'pre_get_posts', 'ce_hpriorders_filter_priority_orders' );
	add_action( 'woocommerce_order_list_table_prepare_items_query_args', 'ce_hpriorders_filter_hpos_priority_orders' );

	// Clear cache when orders are updated.
	add_action( 'woocommerce_new_order', 'ce_hpriorders_clear_count_cache' );
	add_action( 'woocommerce_update_order', 'ce_hpriorders_clear_count_cache' );
	add_action( 'woocommerce_order_status_changed', 'ce_hpriorders_clear_count_cache' );
}

/**
 * Load admin settings class.
 */
function ce_hpriorders_load_admin_settings() {
	include_once CE_HPRIORDERS_PLUGIN_DIR . 'includes/class-admin-settings.php';
	new CE_HPriOrders_Admin_Settings();
}

/**
 * Add settings link on plugin page.
 *
 * @param array $links Existing plugin action links.
 * @return array Modified plugin action links.
 */
function ce_hpriorders_add_settings_link( $links ) {
	$settings_link = sprintf(
		'<a href="%s">%s</a>',
		admin_url( 'admin.php?page=priority-orders-settings' ),
		esc_html__( 'Settings', 'highlight-priority-orders' )
	);
	array_unshift( $links, $settings_link );
	return $links;
}

/**
 * Get configured shipping method IDs.
 *
 * @return array Array of shipping method IDs.
 */
function ce_hpriorders_get_shipping_methods() {
	// Get from database settings.
	$methods = get_option( 'ce_hpriorders_shipping_methods', array() );

	// Allow filters to override (for developers).
	$methods = apply_filters( 'ce_nextday_method_ids', $methods );

	return is_array( $methods ) ? $methods : array();
}

/**
 * Get configured keywords.
 *
 * Keywords allow you to highlight orders based on text in the shipping method name,
 * without needing to configure specific shipping method IDs.
 *
 * USAGE:
 * Add this code to your theme's functions.php or a custom plugin:
 *
 * add_filter( 'ce_nextday_keywords', 'my_priority_keywords' );
 * function my_priority_keywords( $keywords ) {
 *     return array( 'Next Day', 'Express', 'Priority' );
 * }
 *
 * HOW IT WORKS:
 * - Keywords search the shipping method NAME only (what customers see at checkout)
 * - Search is case-insensitive: "next day" matches "Next Day Delivery"
 * - Partial matches work: "Express" matches "Royal Mail Express 24"
 * - Keywords work alongside configured shipping methods (either can trigger highlighting)
 * - Orders must ALSO match a configured order status to be highlighted
 *
 * EXAMPLES:
 * - Keyword: "Next Day" → Matches "Next Day Delivery", "Royal Mail Next Day"
 * - Keyword: "Express" → Matches "DHL Express", "Express Shipping"
 * - Keyword: "24" → Matches "24 Hour Delivery", "Express 24"
 *
 * See FAQ.md for more details and examples.
 *
 * @return array Array of keywords.
 */
function ce_hpriorders_get_keywords() {
	// No UI for keywords - developers can use filter if needed.
	$keywords = apply_filters( 'ce_nextday_keywords', array() );

	return is_array( $keywords ) ? $keywords : array();
}

/**
 * Get configured order statuses.
 *
 * @return array Array of order statuses.
 */
function ce_hpriorders_get_order_statuses() {
	// Get from database settings.
	$statuses = get_option( 'ce_hpriorders_order_statuses', array( 'wc-processing' ) );

	// Remove 'wc-' prefix if present (for compatibility with order->has_status()).
	$statuses = array_map(
		function( $status ) {
			return str_replace( 'wc-', '', $status );
		},
		$statuses
	);

	// Allow filters to override (for developers).
	$statuses = apply_filters( 'ce_nextday_include_statuses', $statuses );

	return is_array( $statuses ) ? $statuses : array( 'processing' );
}

/**
 * Add a class to the <tr> for qualifying orders in the Orders list (CPT).
 *
 * @param array  $classes Array of post classes.
 * @param string $class   Space-separated list of additional classes.
 * @param int    $post_id Post ID.
 * @return array Modified array of post classes.
 */
function ce_hpriorders_add_order_class( $classes, $class, $post_id ) {
	// Only process shop_order post type.
	if ( get_post_type( $post_id ) !== 'shop_order' ) {
		return $classes;
	}

	$order = wc_get_order( $post_id );
	if ( ! $order ) {
		return $classes;
	}

	if ( ce_hpriorders_is_priority_order_object( $order ) ) {
		$classes[] = 'order-nextday';
	}

	return $classes;
}

/**
 * Add a class to the <tr> for qualifying orders in the Orders list (HPOS).
 *
 * @param array    $classes Array of row classes.
 * @param WC_Order $order   The order object.
 * @return array Modified array of row classes.
 */
function ce_hpriorders_add_hpos_order_class( $classes, $order ) {
	if ( ! $order ) {
		return $classes;
	}

	if ( ce_hpriorders_is_priority_order_object( $order ) ) {
		$classes[] = 'order-nextday';
	}

	return $classes;
}

/**
 * Check if an order object is a priority order.
 *
 * @param WC_Order $order The order object.
 * @return bool True if priority order.
 */
function ce_hpriorders_is_priority_order_object( $order ) {
	if ( ! $order ) {
		return false;
	}

	// Get configured settings.
	$keywords   = ce_hpriorders_get_keywords();
	$method_ids = ce_hpriorders_get_shipping_methods();

	$is_priority = false;

	// Check each shipping method.
	foreach ( $order->get_shipping_methods() as $item ) {
		$label = (string) $item->get_name();         // e.g. "Next Day Delivery (Order by 1pm)".
		$mid   = (string) $item->get_method_id();    // e.g. "flat_rate" / "royal_mail".
		$iid   = (string) $item->get_instance_id();  // e.g. "3".
		$full  = $iid ? "{$mid}:{$iid}" : $mid;

		// Keyword check on the label.
		foreach ( $keywords as $kw ) {
			if ( '' !== $kw && false !== stripos( $label, $kw ) ) {
				$is_priority = true;
				break 2;
			}
		}

		// Explicit method ID / instance check.
		if ( in_array( $full, $method_ids, true ) || in_array( $mid, $method_ids, true ) ) {
			$is_priority = true;
			break;
		}
	}

	// Only apply to these order statuses.
	$include_statuses = ce_hpriorders_get_order_statuses();

	return $is_priority && $order->has_status( $include_statuses );
}

/**
 * Add styling on the Orders screen to highlight next-day orders.
 * Works with both CPT and HPOS order screens.
 */
function ce_hpriorders_admin_order_list_styles() {
	$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
	if ( ! $screen ) {
		return;
	}

	// Check if we're on either the CPT or HPOS orders screen.
	$is_orders_screen = in_array( $screen->id, array( 'edit-shop_order', 'woocommerce_page_wc-orders' ), true );
	if ( ! $is_orders_screen ) {
		return;
	}

	// Get appearance settings.
	$tag_emoji        = get_option( 'ce_hpriorders_tag_emoji', '⚡' );
	$tag_text         = get_option( 'ce_hpriorders_tag_text', 'Next-day' );
	$background_color = get_option( 'ce_hpriorders_background_color', '#fff7d6' );
	$border_color     = get_option( 'ce_hpriorders_border_color', '#f59e0b' );

	// Build the tag content.
	$tag_content = '';
	if ( ! empty( $tag_emoji ) ) {
		$tag_content .= $tag_emoji . ' ';
	}
	$tag_content .= $tag_text;

	// Sanitize colors.
	$background_color = sanitize_hex_color( $background_color );
	$border_color     = sanitize_hex_color( $border_color );

	?>
	<style>
		/* Soft highlight across the row - works with both CPT and HPOS */
		.wp-list-table .order-nextday,
		.wp-list-table tr.order-nextday {
			background: <?php echo esc_attr( $background_color ); ?> !important;
		}
		/* A bold left bar to catch the eye - CPT */
		.wp-list-table .order-nextday th:first-child {
			border-left: 6px solid <?php echo esc_attr( $border_color ); ?>;
		}
		/* A bold left bar to catch the eye - HPOS */
		.wp-list-table tr.order-nextday td:first-child {
			border-left: 6px solid <?php echo esc_attr( $border_color ); ?>;
		}
		/* Tag in the Order column - CPT */
		.wp-list-table .order-nextday .order_number a::after,
		.wp-list-table .order-nextday .order_title a::after {
			content: "  <?php echo esc_js( $tag_content ); ?>";
			font-weight: 600;
			color: <?php echo esc_attr( $border_color ); ?>;
			display: block;
		}
		/* Tag in the Order column - HPOS */
		.wp-list-table tr.order-nextday .column-order_number a::after {
			content: "  <?php echo esc_js( $tag_content ); ?>";
			font-weight: 600;
			color: <?php echo esc_attr( $border_color ); ?>;
			display: block;
		}
	</style>
	<?php
}

/**
 * Add Priority filter link to orders list (CPT).
 *
 * @param array $views Existing views.
 * @return array Modified views.
 */
function ce_hpriorders_add_priority_filter_link( $views ) {
	// Get configured settings.
	$method_ids = ce_hpriorders_get_shipping_methods();

	// Don't show if no methods configured.
	if ( empty( $method_ids ) ) {
		return $views;
	}

	// Get count of priority orders.
	$count = ce_hpriorders_get_priority_count();

	// Check if we're currently viewing priority orders.
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended
	$current = isset( $_GET['priority_orders'] ) && '1' === $_GET['priority_orders'];

	// Build the URL.
	$url = add_query_arg(
		array(
			'post_type'       => 'shop_order',
			'priority_orders' => '1',
		),
		admin_url( 'edit.php' )
	);

	// Build the link HTML with count.
	$class = $current ? 'current' : '';
	$views['priority_orders'] = sprintf(
		'<a href="%s" class="%s">%s <span class="count">(%d)</span></a>',
		esc_url( $url ),
		esc_attr( $class ),
		esc_html__( 'Priority', 'highlight-priority-orders' ),
		absint( $count )
	);

	return $views;
}

/**
 * Add Priority filter link to orders list (HPOS).
 *
 * @param array $views Existing views.
 * @return array Modified views.
 */
function ce_hpriorders_add_hpos_priority_filter_link( $views ) {
	// Get configured settings.
	$method_ids = ce_hpriorders_get_shipping_methods();

	// Don't show if no methods configured.
	if ( empty( $method_ids ) ) {
		return $views;
	}

	// Get count of priority orders.
	$count = ce_hpriorders_get_priority_count();

	// Check if we're currently viewing priority orders.
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended
	$current = isset( $_GET['priority_orders'] ) && '1' === $_GET['priority_orders'];

	// Build the URL for HPOS.
	$url = add_query_arg(
		array(
			'page'            => 'wc-orders',
			'priority_orders' => '1',
		),
		admin_url( 'admin.php' )
	);

	// Build the link HTML with count.
	$class = $current ? 'current' : '';
	$views['priority_orders'] = sprintf(
		'<a href="%s" class="%s">%s <span class="count">(%d)</span></a>',
		esc_url( $url ),
		esc_attr( $class ),
		esc_html__( 'Priority', 'highlight-priority-orders' ),
		absint( $count )
	);

	return $views;
}

/**
 * Check if HPOS is enabled.
 *
 * @return bool True if HPOS is enabled.
 */
function ce_hpriorders_is_hpos_enabled() {
	if ( class_exists( '\Automattic\WooCommerce\Utilities\OrderUtil' ) ) {
		return \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled();
	}
	return false;
}

/**
 * Get count of priority orders using efficient database query.
 * Works with both CPT and HPOS.
 *
 * @return int Number of priority orders.
 */
function ce_hpriorders_get_priority_count() {
	// Get configured shipping methods and statuses.
	$method_ids = ce_hpriorders_get_shipping_methods();
	$statuses   = ce_hpriorders_get_order_statuses();

	if ( empty( $method_ids ) || empty( $statuses ) ) {
		return 0;
	}

	// Create cache key based on methods, statuses, and HPOS status.
	$hpos_enabled = ce_hpriorders_is_hpos_enabled();
	$cache_key    = 'ce_hpriorders_count_' . md5( wp_json_encode( array( $method_ids, $statuses, $hpos_enabled ) ) );
	$count        = wp_cache_get( $cache_key, 'ce_hpriorders' );

	if ( false !== $count ) {
		return absint( $count );
	}

	// Use appropriate counting method based on HPOS status.
	if ( $hpos_enabled ) {
		$count = ce_hpriorders_get_priority_count_hpos( $method_ids, $statuses );
	} else {
		$count = ce_hpriorders_get_priority_count_cpt( $method_ids, $statuses );
	}

	$count = absint( $count );

	// Cache for 5 minutes.
	wp_cache_set( $cache_key, $count, 'ce_hpriorders', 5 * MINUTE_IN_SECONDS );

	return $count;
}

/**
 * Get count of priority orders from CPT tables.
 *
 * @param array $method_ids Array of shipping method IDs.
 * @param array $statuses   Array of order statuses.
 * @return int Number of priority orders.
 */
function ce_hpriorders_get_priority_count_cpt( $method_ids, $statuses ) {
	global $wpdb;

	// Build SQL conditions for shipping methods.
	$placeholders = array();
	$values       = array();

	foreach ( $method_ids as $method_id ) {
		$parts = explode( ':', $method_id );
		if ( count( $parts ) === 2 ) {
			$placeholders[] = '(oim_method.meta_value = %s AND oim_instance.meta_value = %s)';
			$values[]       = $parts[0];
			$values[]       = $parts[1];
		} else {
			$placeholders[] = 'oim_method.meta_value = %s';
			$values[]       = $method_id;
		}
	}

	if ( empty( $placeholders ) ) {
		return 0;
	}

	// phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter
	$conditions = implode( ' OR ', $placeholders );

	// Add status placeholders.
	$status_placeholders = implode( ',', array_fill( 0, count( $statuses ), '%s' ) );
	$status_values       = array_map( function( $status ) {
		return 'wc-' . $status;
	}, $statuses );

	// Merge all values.
	$all_values = array_merge( $status_values, $values );

	// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
	$count = $wpdb->get_var(
		$wpdb->prepare(
			"
			SELECT COUNT(DISTINCT p.ID)
			FROM {$wpdb->posts} AS p
			INNER JOIN {$wpdb->prefix}woocommerce_order_items AS oi
				ON p.ID = oi.order_id
			INNER JOIN {$wpdb->prefix}woocommerce_order_itemmeta AS oim_method
				ON oi.order_item_id = oim_method.order_item_id
				AND oim_method.meta_key = 'method_id'
			LEFT JOIN {$wpdb->prefix}woocommerce_order_itemmeta AS oim_instance
				ON oi.order_item_id = oim_instance.order_item_id
				AND oim_instance.meta_key = 'instance_id'
			WHERE p.post_type = 'shop_order'
			AND p.post_status IN ({$status_placeholders})
			AND oi.order_item_type = 'shipping'
			AND ({$conditions})
			",
			$all_values
		)
	);
	// phpcs:enable

	return absint( $count );
}

/**
 * Get count of priority orders from HPOS tables.
 *
 * @param array $method_ids Array of shipping method IDs.
 * @param array $statuses   Array of order statuses.
 * @return int Number of priority orders.
 */
function ce_hpriorders_get_priority_count_hpos( $method_ids, $statuses ) {
	global $wpdb;

	// Build SQL conditions for shipping methods.
	$placeholders = array();
	$values       = array();

	foreach ( $method_ids as $method_id ) {
		$parts = explode( ':', $method_id );
		if ( count( $parts ) === 2 ) {
			$placeholders[] = '(oim_method.meta_value = %s AND oim_instance.meta_value = %s)';
			$values[]       = $parts[0];
			$values[]       = $parts[1];
		} else {
			$placeholders[] = 'oim_method.meta_value = %s';
			$values[]       = $method_id;
		}
	}

	if ( empty( $placeholders ) ) {
		return 0;
	}

	// phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter
	$conditions = implode( ' OR ', $placeholders );

	// Add status placeholders.
	$status_placeholders = implode( ',', array_fill( 0, count( $statuses ), '%s' ) );
	$status_values       = array_map( function( $status ) {
		return 'wc-' . str_replace( 'wc-', '', $status );
	}, $statuses );

	// Merge all values.
	$all_values = array_merge( $status_values, $values );

	// Query the HPOS orders table.
	// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
	$count = $wpdb->get_var(
		$wpdb->prepare(
			"
			SELECT COUNT(DISTINCT o.id)
			FROM {$wpdb->prefix}wc_orders AS o
			INNER JOIN {$wpdb->prefix}woocommerce_order_items AS oi
				ON o.id = oi.order_id
			INNER JOIN {$wpdb->prefix}woocommerce_order_itemmeta AS oim_method
				ON oi.order_item_id = oim_method.order_item_id
				AND oim_method.meta_key = 'method_id'
			LEFT JOIN {$wpdb->prefix}woocommerce_order_itemmeta AS oim_instance
				ON oi.order_item_id = oim_instance.order_item_id
				AND oim_instance.meta_key = 'instance_id'
			WHERE o.type = 'shop_order'
			AND o.status IN ({$status_placeholders})
			AND oi.order_item_type = 'shipping'
			AND ({$conditions})
			",
			$all_values
		)
	);
	// phpcs:enable

	return absint( $count );
}

/**
 * Filter orders query to show only priority orders (CPT).
 *
 * @param WP_Query $query The query object.
 */
function ce_hpriorders_filter_priority_orders( $query ) {
	global $pagenow, $typenow;

	// Only on orders admin page.
	if ( 'edit.php' !== $pagenow || 'shop_order' !== $typenow || ! $query->is_main_query() ) {
		return;
	}

	// Check if priority filter is active.
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended
	if ( ! isset( $_GET['priority_orders'] ) || '1' !== $_GET['priority_orders'] ) {
		return;
	}

	// Get all orders with configured statuses.
	$statuses = ce_hpriorders_get_order_statuses();

	// Add status filter to query.
	$query->set( 'post_status', array_map( function( $status ) {
		return 'wc-' . $status;
	}, $statuses ) );

	// Add custom WHERE clause to filter by shipping method at database level.
	add_filter( 'posts_where', 'ce_hpriorders_filter_where_clause', 10, 2 );
}

/**
 * Filter orders query to show only priority orders (HPOS).
 *
 * @param array $query_vars The query vars.
 * @return array Modified query vars.
 */
function ce_hpriorders_filter_hpos_priority_orders( $query_vars ) {
	// Check if priority filter is active.
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended
	if ( ! isset( $_GET['priority_orders'] ) || '1' !== $_GET['priority_orders'] ) {
		return $query_vars;
	}

	// Get configured statuses.
	$statuses = ce_hpriorders_get_order_statuses();

	// Add status filter.
	if ( ! empty( $statuses ) ) {
		$query_vars['status'] = $statuses;
	}

	// Add custom filter for shipping method.
	add_filter( 'woocommerce_order_list_table_prepare_items_query_args', 'ce_hpriorders_filter_hpos_by_shipping', 20 );
	add_action( 'woocommerce_order_query', 'ce_hpriorders_hpos_query_filter' );

	return $query_vars;
}

/**
 * Filter HPOS orders by shipping method.
 *
 * @param \Automattic\WooCommerce\Internal\DataStores\Orders\OrdersTableQuery $query The order query object.
 */
function ce_hpriorders_hpos_query_filter( $query ) {
	// Check if priority filter is active.
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended
	if ( ! isset( $_GET['priority_orders'] ) || '1' !== $_GET['priority_orders'] ) {
		return;
	}

	global $wpdb;

	// Get configured shipping methods.
	$method_ids = ce_hpriorders_get_shipping_methods();
	if ( empty( $method_ids ) ) {
		return;
	}

	// Build SQL to find orders with priority shipping methods.
	$placeholders = array();
	$values       = array();

	foreach ( $method_ids as $method_id ) {
		$parts = explode( ':', $method_id );
		if ( count( $parts ) === 2 ) {
			$placeholders[] = '(oim_method.meta_value = %s AND oim_instance.meta_value = %s)';
			$values[]       = $parts[0];
			$values[]       = $parts[1];
		} else {
			$placeholders[] = 'oim_method.meta_value = %s';
			$values[]       = $method_id;
		}
	}

	if ( empty( $placeholders ) ) {
		return;
	}

	// phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter
	$conditions = implode( ' OR ', $placeholders );

	// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
	$subquery = $wpdb->prepare(
		"
		SELECT DISTINCT oi.order_id
		FROM {$wpdb->prefix}woocommerce_order_items AS oi
		INNER JOIN {$wpdb->prefix}woocommerce_order_itemmeta AS oim_method
			ON oi.order_item_id = oim_method.order_item_id
			AND oim_method.meta_key = 'method_id'
		LEFT JOIN {$wpdb->prefix}woocommerce_order_itemmeta AS oim_instance
			ON oi.order_item_id = oim_instance.order_item_id
			AND oim_instance.meta_key = 'instance_id'
		WHERE oi.order_item_type = 'shipping'
		AND ({$conditions})
		",
		$values
	);
	// phpcs:enable

	// Add the WHERE clause to the query.
	$query->set( 'id', $subquery );
}

/**
 * Add WHERE clause to filter orders by shipping method.
 *
 * @param string   $where The WHERE clause.
 * @param WP_Query $query The query object.
 * @return string Modified WHERE clause.
 */
function ce_hpriorders_filter_where_clause( $where, $query ) {
	global $wpdb;

	// Remove this filter to avoid affecting other queries.
	remove_filter( 'posts_where', 'ce_hpriorders_filter_where_clause', 10 );

	// Check if this is our priority filter query.
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended
	if ( ! isset( $_GET['priority_orders'] ) || '1' !== $_GET['priority_orders'] ) {
		return $where;
	}

	// Get configured shipping methods.
	$method_ids = ce_hpriorders_get_shipping_methods();
	if ( empty( $method_ids ) ) {
		return $where;
	}

	// Build SQL to find orders with priority shipping methods.
	// WooCommerce stores shipping methods in order items (woocommerce_order_items table).
	// and the method details in order item meta (woocommerce_order_itemmeta table).
	// Note: $placeholders contains only hardcoded SQL with %s placeholders (safe).
	// The actual values are sanitized by $wpdb->prepare() through $values array.
	$placeholders = array();
	$values       = array();

	foreach ( $method_ids as $method_id ) {
		// Handle both "method_id:instance_id" and just "method_id" formats.
		$parts = explode( ':', $method_id );
		if ( count( $parts ) === 2 ) {
			// Full format: method_id:instance_id - hardcoded SQL with placeholders.
			$placeholders[] = '(oim_method.meta_value = %s AND oim_instance.meta_value = %s)';
			$values[]       = $parts[0];
			$values[]       = $parts[1];
		} else {
			// Just method_id - hardcoded SQL with placeholder.
			$placeholders[] = 'oim_method.meta_value = %s';
			$values[]       = $method_id;
		}
	}

	if ( empty( $placeholders ) ) {
		return $where;
	}

	// $conditions contains only hardcoded SQL fragments with %s placeholders.
	// phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter
	$conditions = implode( ' OR ', $placeholders );

	// Build the query - $conditions contains dynamically built placeholders.
	// $conditions is safe: it contains only hardcoded SQL with %s placeholders, actual values go through $wpdb->prepare().
	// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, PluginCheck.Security.DirectDB.UnescapedDBParameter
	$subquery = $wpdb->prepare(
		"
		SELECT DISTINCT oi.order_id
		FROM {$wpdb->prefix}woocommerce_order_items AS oi
		INNER JOIN {$wpdb->prefix}woocommerce_order_itemmeta AS oim_method
			ON oi.order_item_id = oim_method.order_item_id
			AND oim_method.meta_key = 'method_id'
		LEFT JOIN {$wpdb->prefix}woocommerce_order_itemmeta AS oim_instance
			ON oi.order_item_id = oim_instance.order_item_id
			AND oim_instance.meta_key = 'instance_id'
		WHERE oi.order_item_type = 'shipping'
		AND ({$conditions})
		",
		$values
	);
	// phpcs:enable

	// Add the subquery to the WHERE clause.
	$where .= " AND {$wpdb->posts}.ID IN ({$subquery})";

	return $where;
}

/**
 * Check if an order is a priority order.
 *
 * @param int   $order_id Order ID.
 * @param array $method_ids Array of shipping method IDs.
 * @param array $keywords Array of keywords.
 * @return bool True if priority order.
 */
function ce_hpriorders_is_priority_order( $order_id, $method_ids = array(), $keywords = array() ) {
	// Safety checks.
	if ( empty( $order_id ) || ! function_exists( 'wc_get_order' ) ) {
		return false;
	}

	$order = wc_get_order( $order_id );
	if ( ! $order ) {
		return false;
	}

	// If no methods configured, can't be priority.
	if ( empty( $method_ids ) && empty( $keywords ) ) {
		return false;
	}

	$is_priority = false;

	// Check each shipping method.
	$shipping_methods = $order->get_shipping_methods();
	if ( empty( $shipping_methods ) ) {
		return false;
	}

	foreach ( $shipping_methods as $item ) {
		if ( ! is_object( $item ) ) {
			continue;
		}

		$label = (string) $item->get_name();
		$mid   = (string) $item->get_method_id();
		$iid   = (string) $item->get_instance_id();
		$full  = $iid ? "{$mid}:{$iid}" : $mid;

		// Keyword check.
		if ( ! empty( $keywords ) ) {
			foreach ( $keywords as $kw ) {
				if ( '' !== $kw && false !== stripos( $label, $kw ) ) {
					$is_priority = true;
					break 2;
				}
			}
		}

		// Method ID check.
		if ( ! empty( $method_ids ) && ( in_array( $full, $method_ids, true ) || in_array( $mid, $method_ids, true ) ) ) {
			$is_priority = true;
			break;
		}
	}

	return $is_priority;
}

/**
 * Clear the priority orders count cache.
 */
function ce_hpriorders_clear_count_cache() {
	// Get current configuration to build cache key.
	$method_ids = ce_hpriorders_get_shipping_methods();
	$statuses   = ce_hpriorders_get_order_statuses();

	if ( ! empty( $method_ids ) && ! empty( $statuses ) ) {
		$cache_key = 'ce_hpriorders_count_' . md5( wp_json_encode( array( $method_ids, $statuses ) ) );
		wp_cache_delete( $cache_key, 'ce_hpriorders' );
	}
}
